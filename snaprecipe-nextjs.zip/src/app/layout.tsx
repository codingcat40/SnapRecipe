import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'SnapRecipe — Scan any dish, get the full recipe',
  description: 'Upload a food photo and instantly get ingredients, cooking steps, and macros. Powered by AI.',
  openGraph: {
    title: 'SnapRecipe',
    description: 'Scan any dish, get the full recipe + macros instantly.',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
